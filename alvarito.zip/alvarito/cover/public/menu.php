

<header class="mb-auto">
    <div>
      <h3 class="float-md-start mb-0">Pagina</h3>
      <nav class="nav nav-masthead justify-content-center float-md-end">
        <a class="nav-link fw-bold py-1 px-0 active" aria-current="page" href="index.php">Inicio</a>
        <a class="nav-link fw-bold py-1 px-0" href="caracteristicas.php">Caracteristicas</a>
        <a class="nav-link fw-bold py-1 px-0" href="detalles.php">Detalles tecnicos</a>
        <a class="nav-link fw-bold py-1 px-0" href="soporte.php">Soporte tecnico</a>
        <a class="nav-link fw-bold py-1 px-0" href="ayuda.php">ayuda</a>
      </nav>
    </div>

  </header>